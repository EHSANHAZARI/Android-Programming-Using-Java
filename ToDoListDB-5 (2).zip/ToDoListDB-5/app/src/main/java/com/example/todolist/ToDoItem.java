package com.example.todolist;

import android.text.format.DateUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ToDoItem {

    private String description;
    private boolean isComplete;
    private long id;
    private long time;

    public ToDoItem(String description, boolean isComplete , long time) {
        this(description, isComplete, -1 , time);
    }

    public ToDoItem(String description, boolean isComplete, long id , long time) {
        this.description = description;
        this.isComplete = isComplete;
        this.id = id;
        this.time = time;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public boolean isComplete() {
        return isComplete;
    }

    public void toggleComplete() {
        isComplete = !isComplete;
    }

    public long getId() { return id; }


    @Override
    public String toString() {
        return getDescription();
    }
}
