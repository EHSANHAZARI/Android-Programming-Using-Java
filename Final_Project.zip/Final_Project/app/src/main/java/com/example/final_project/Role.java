package com.example.final_project;

public class Role extends Player {
    private int players = 0;
    private boolean isCollapsed = true;

    public Role(String name, String description) {
        super(name, description);
    }

    // This function returns the player.
    public int getPlayers() {
        return players;
    }

    // This function add one to the number of players
    public void addPlayer() {
        players++;
    }

    // This function check if the number of player is posetive then reduce the player number by one
    public void removePlayer() {
        if (players > 0) {
            players--;
        }
    }

    public void setCollapsed(boolean collapsed) {
        isCollapsed = collapsed;
    }

    public boolean isCollapsed() {
        return isCollapsed;
    }

    public void resetNumPlayers() {
        players = 0;
    }
}

