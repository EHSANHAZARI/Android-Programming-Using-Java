package com.example.final_project;

import android.content.res.AssetManager;
import android.util.JsonReader;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;



public class RoleLoader {
    public static final String ROLE_DESCRIPTION_FILE = "roles.json";
    public static final String NAME_PROPERTY = "name";
    public static final String DESCRIPTION_PROPERTY = "description";
    private static final String LOG_TAG = "RoleLoader";

    public static ArrayList<Role> loadRoles(AssetManager assetManager) {
        try (InputStream is = roleInputStream(assetManager)) {
            return readJSON(is);
        } catch (IOException e) {
            Log.e(LOG_TAG, "IOException");
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // This method read roles from the role file
    private static ArrayList<Role> readJSON(InputStream in) throws IOException {
        try (JsonReader reader = new JsonReader(new InputStreamReader(in, "UTF-8"))) {
            return readRolesIn(reader);
        }
    }

    //This method add an array into an other array until it is not null
    private static ArrayList<Role> readRolesIn(JsonReader reader) throws IOException {
        ArrayList<Role> roles = new ArrayList<>();
        reader.beginArray();
        while (reader.hasNext()) {
            Role r = readRole(reader);
            if (r != null) {
                roles.add(r);
            }
        }
        reader.endArray();
        return roles;
    }

    private static Role readRole(JsonReader reader) throws IOException {
        String name = null;
        String description = null;
        reader.beginObject();
        while (reader.hasNext()) {
            String property = reader.nextName();
            switch (property) {
                case NAME_PROPERTY:
                    name = reader.nextString();
                    break;
                case DESCRIPTION_PROPERTY:
                    description = reader.nextString();
                    break;
                default:
                    Log.w(LOG_TAG, "Unknown property: " + property);
                    break;
            }
        }
        if (name == null || description == null) {
            Log.w(LOG_TAG, "name: " + name + ", description: " + description);
            return null;
        }
        reader.endObject();
        return new Role(name, description);
    }

    private static InputStream roleInputStream(AssetManager assetManager) throws IOException {
        return assetManager.open(ROLE_DESCRIPTION_FILE);
    }

}
